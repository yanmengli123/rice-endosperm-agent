/* Paper China - Frontend Application */

let papers = [];
let currentPaper = null;
let selectedFiles = [];
let selectedFileKeys = new Set();
const RESUMABLE_UPLOAD_THRESHOLD = 8 * 1024 * 1024;
const RESUMABLE_UPLOAD_STORAGE_KEY = 'paperChinaPendingUploads';
function loadPendingUploadSessions() {
  try {
    const entries = JSON.parse(localStorage.getItem(RESUMABLE_UPLOAD_STORAGE_KEY) || '[]');
    return new Map(Array.isArray(entries) ? entries : []);
  } catch {
    return new Map();
  }
}
const pendingUploadSessions = loadPendingUploadSessions();
let searchTimer = null;
let translationPollId = null;
let translationPollPaperId = null;
let translationPollGeneration = 0;
let pagination = { offset: 0, limit: 50, total: 0 };
let currentLoadId = 0; // Track which paper is being loaded to prevent race conditions

// === API ===
async function errorDetail(res, fallback) {
  try { return (await res.json()).detail || fallback; } catch { return fallback; }
}

function getApiToken() {
  return localStorage.getItem('paperChinaApiToken') || '';
}

function authHeaders(extra = {}) {
  const token = getApiToken();
  return token ? { ...extra, Authorization: `Bearer ${token}` } : extra;
}

// === Login ===
let loginPromptPromise = null;
let providerSettingsReturnFocus = null;

function focusableElements(container) {
  return Array.from(container?.querySelectorAll(
    'a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), '
    + 'textarea:not([disabled]), [tabindex]:not([tabindex="-1"])'
  ) || []).filter(element => !element.closest('.hidden'));
}

function trapModalFocus(modal, event) {
  if (event.key !== 'Tab' || !modal || modal.classList.contains('hidden')) return false;
  const focusable = focusableElements(modal);
  if (focusable.length === 0) return false;
  const first = focusable[0];
  const last = focusable[focusable.length - 1];
  if (event.shiftKey && document.activeElement === first) {
    last.focus();
    event.preventDefault();
    return true;
  }
  if (!event.shiftKey && document.activeElement === last) {
    first.focus();
    event.preventDefault();
    return true;
  }
  if (!modal.contains(document.activeElement)) {
    first.focus();
    event.preventDefault();
    return true;
  }
  return false;
}

function showLoginModal() {
  document.getElementById('login-modal')?.classList.remove('hidden');
  setTimeout(() => document.getElementById('login-username')?.focus(), 50);
}

function hideLoginModal() {
  document.getElementById('login-modal')?.classList.add('hidden');
  const err = document.getElementById('login-error');
  if (err) err.textContent = '';
}

function updateCurrentUserBadge() {
  const username = localStorage.getItem('paperChinaUsername') || '';
  const badge = document.getElementById('current-user');
  const logoutBtn = document.getElementById('btn-logout');
  if (badge) {
    badge.textContent = username ? `👤 ${username}` : '';
    badge.classList.toggle('hidden', !username);
  }
  logoutBtn?.classList.toggle('hidden', !username);
}

function requestLogin() {
  // Single shared promise: concurrent 401s open only one modal.
  if (!loginPromptPromise) {
    loginPromptPromise = new Promise((resolve) => {
      const form = document.getElementById('login-form');
      if (!form) { resolve(false); return; }
      showLoginModal();
      const onSubmit = async (e) => {
        e.preventDefault();
        const username = document.getElementById('login-username').value.trim();
        const password = document.getElementById('login-password').value;
        const err = document.getElementById('login-error');
        const submitBtn = document.getElementById('login-submit');
        err.textContent = '';
        submitBtn.disabled = true;
        try {
          const res = await fetch('/api/auth/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password }),
          });
          if (!res.ok) {
            err.textContent = (await res.json()).detail || '登录失败';
            return;
          }
          const data = await res.json();
          localStorage.setItem('paperChinaApiToken', data.token);
          localStorage.setItem('paperChinaUsername', data.username);
          form.removeEventListener('submit', onSubmit);
          hideLoginModal();
          updateCurrentUserBadge();
          resolve(true);
        } catch {
          err.textContent = '网络错误，请重试';
        } finally {
          submitBtn.disabled = false;
        }
      };
      form.addEventListener('submit', onSubmit);
    }).finally(() => { loginPromptPromise = null; });
  }
  return loginPromptPromise;
}

function logout() {
  hideProviderSettings();
  localStorage.removeItem('paperChinaApiToken');
  localStorage.removeItem('paperChinaUsername');
  updateCurrentUserBadge();
  showLoginModal();
  loadPapers();
}

async function apiFetch(url, options = {}, retryAuth = true) {
  const headers = authHeaders(options.headers || {});
  const res = await fetch(url, { ...options, headers });
  if (res.status === 401 && retryAuth) {
    localStorage.removeItem('paperChinaApiToken');
    if (await requestLogin()) {
      return apiFetch(url, options, false);
    }
  }
  return res;
}

const api = {
  async listPapers(search = '', status = '', tag = '', offset = 0, limit = 50) {
    const params = new URLSearchParams();
    if (search) params.set('search', search);
    if (status) params.set('status', status);
    if (tag) params.set('tag', tag);
    params.set('offset', offset);
    params.set('limit', limit);
    const res = await apiFetch(`/api/papers/?${params}`);
    if (!res.ok) throw new Error(await errorDetail(res, 'Failed to load papers'));
    return res.json();
  },
  async uploadPaper(file, tags = '') {
    const form = new FormData();
    form.append('file', file);
    if (tags) form.append('tags', tags);
    const res = await apiFetch('/api/papers/upload', { method: 'POST', body: form });
    if (!res.ok) throw new Error(await errorDetail(res, 'Upload failed'));
    return res.json();
  },
  uploadPaperWithProgress(file, tags, onProgress) {
    return new Promise((resolve, reject) => {
      const form = new FormData();
      form.append('file', file);
      if (tags) form.append('tags', tags);
      const xhr = new XMLHttpRequest();
      xhr.upload.addEventListener('progress', e => {
        if (e.lengthComputable) onProgress(e.loaded / e.total);
      });
      xhr.addEventListener('load', () => {
        if (xhr.status >= 200 && xhr.status < 300) {
          try { resolve(JSON.parse(xhr.responseText)); }
          catch { reject(new Error('服务器返回了无效的上传结果，请重试')); }
        } else {
          try { reject(new Error(JSON.parse(xhr.responseText).detail || 'Upload failed')); }
          catch { reject(new Error('Upload failed')); }
        }
      });
      xhr.addEventListener('error', () => reject(new Error('Network error')));
      xhr.open('POST', '/api/papers/upload');
      const token = getApiToken();
      if (token) xhr.setRequestHeader('Authorization', `Bearer ${token}`);
      xhr.send(form);
    });
  },
  async initResumableUpload(file, tags = '', uploadId = '') {
    const res = await apiFetch('/api/papers/uploads/init', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        filename: file.name,
        file_size: file.size,
        tags,
        client_upload_id: uploadId || null,
      }),
    });
    if (!res.ok) throw new Error(await errorDetail(res, '无法初始化分片上传'));
    return res.json();
  },
  async getResumableUpload(uploadId) {
    const res = await apiFetch(`/api/papers/uploads/${encodeURIComponent(uploadId)}`);
    if (!res.ok) {
      const error = new Error(await errorDetail(res, '上传会话已失效'));
      error.status = res.status;
      throw error;
    }
    return res.json();
  },
  uploadResumableChunk(uploadId, index, chunk, sha256, onProgress) {
    return new Promise((resolve, reject) => {
      const xhr = new XMLHttpRequest();
      xhr.upload.addEventListener('progress', e => {
        if (e.lengthComputable) onProgress(e.loaded);
      });
      xhr.addEventListener('load', () => {
        if (xhr.status >= 200 && xhr.status < 300) {
          try { resolve(JSON.parse(xhr.responseText)); }
          catch { reject(new Error('服务器返回了无效的分片结果')); }
        } else {
          try { reject(new Error(JSON.parse(xhr.responseText).detail || '分片上传失败')); }
          catch { reject(new Error(`分片上传失败 (${xhr.status || '网络中断'})`)); }
        }
      });
      xhr.addEventListener('error', () => reject(new Error('网络中断')));
      xhr.addEventListener('timeout', () => reject(new Error('分片上传超时')));
      xhr.open('PUT', `/api/papers/uploads/${encodeURIComponent(uploadId)}/chunks/${index}`);
      xhr.timeout = 60_000;
      xhr.setRequestHeader('Content-Type', 'application/octet-stream');
      xhr.setRequestHeader('X-Chunk-SHA256', sha256);
      const token = getApiToken();
      if (token) xhr.setRequestHeader('Authorization', `Bearer ${token}`);
      xhr.send(chunk);
    });
  },
  async completeResumableUpload(uploadId) {
    const res = await apiFetch(
      `/api/papers/uploads/${encodeURIComponent(uploadId)}/complete`,
      { method: 'POST' }
    );
    if (!res.ok) throw new Error(await errorDetail(res, '无法完成分片上传'));
    return res.json();
  },
  async getPaper(id) {
    const res = await apiFetch(`/api/papers/${id}`);
    if (!res.ok) throw new Error(await errorDetail(res, 'Paper not found'));
    return res.json();
  },
  async translatePaper(id, backend = '', quality = 'balanced', options = {}) {
    const params = new URLSearchParams();
    if (backend) params.set('backend', backend);
    if (quality) params.set('quality', quality);
    if (Object.prototype.hasOwnProperty.call(options, 'preserve_graphics_text')) {
      params.set('preserve_graphics_text', options.preserve_graphics_text ? 'true' : 'false');
    }
    if (options.skip_overflow) params.set('skip_overflow', 'true');
    if (options.qa_mode) params.set('qa_mode', options.qa_mode);
    if (options.qa_max_passes) params.set('qa_max_passes', String(options.qa_max_passes));
    if (options.ocr_mode) params.set('ocr_mode', options.ocr_mode);
    const res = await apiFetch(`/api/papers/${id}/translate?${params}`, { method: 'POST' });
    if (!res.ok) throw new Error(await errorDetail(res, 'Translation failed'));
    return res.json();
  },
  async listProviderCredentials() {
    const res = await apiFetch('/api/provider-credentials');
    if (!res.ok) throw new Error(await errorDetail(res, 'API 配置加载失败'));
    return res.json();
  },
  async listProviderModels() {
    const res = await apiFetch('/api/provider-credentials/models');
    if (!res.ok) throw new Error(await errorDetail(res, '模型列表加载失败'));
    return res.json();
  },
  async refreshProviderModels(provider) {
    const res = await apiFetch(
      `/api/provider-credentials/models/${encodeURIComponent(provider)}/refresh`,
      { method: 'POST' }
    );
    if (!res.ok) throw new Error(await errorDetail(res, '模型列表更新失败'));
    return res.json();
  },
  async saveProviderCredential(provider, payload) {
    const res = await apiFetch(`/api/provider-credentials/${encodeURIComponent(provider)}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    if (!res.ok) throw new Error(await errorDetail(res, 'API 配置保存失败'));
    return res.json();
  },
  async deleteProviderCredential(provider) {
    const res = await apiFetch(`/api/provider-credentials/${encodeURIComponent(provider)}`, {
      method: 'DELETE',
    });
    if (!res.ok) throw new Error(await errorDetail(res, 'API 配置删除失败'));
    return res.json();
  },
  async cancelTranslation(id) {
    const res = await apiFetch(`/api/papers/${id}/cancel`, { method: 'POST' });
    if (!res.ok) throw new Error(await errorDetail(res, 'Cancel failed'));
    return res.json();
  },
  async deletePaper(id) {
    const res = await apiFetch(`/api/papers/${id}`, { method: 'DELETE' });
    if (!res.ok) throw new Error(await errorDetail(res, 'Delete failed'));
    return res.json();
  },
  async updatePaper(id, data) {
    const res = await apiFetch(`/api/papers/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!res.ok) throw new Error(await errorDetail(res, 'Update failed'));
    return res.json();
  },
  async getStats() {
    const res = await apiFetch('/api/stats');
    if (!res.ok) throw new Error(await errorDetail(res, 'Failed to load stats'));
    return res.json();
  },
  async getQaReport(id) {
    const res = await apiFetch(`/api/papers/${id}/qa-report`);
    if (!res.ok) throw new Error(await errorDetail(res, '质检报告不可用'));
    return res.json();
  },
  async getEditableFigureManifest(id) {
    const res = await apiFetch(`/api/papers/${id}/editable-figures/source-manifest`);
    if (!res.ok) throw new Error(await errorDetail(res, '图形素材清单不可用'));
    return res.json();
  },
  async extractEditableFigures(id) {
    const res = await apiFetch(`/api/papers/${id}/editable-figures/extract`, { method: 'POST' });
    if (!res.ok) throw new Error(await errorDetail(res, '图形素材提取失败'));
    return res.json();
  }
};

// === Provider credentials ===
function hideProviderSettings() {
  const modal = document.getElementById('provider-settings-modal');
  const wasOpen = modal && !modal.classList.contains('hidden');
  modal?.classList.add('hidden');
  modal?.querySelectorAll('.provider-key').forEach(input => { input.value = ''; });
  const error = document.getElementById('provider-settings-error');
  if (error) error.textContent = '';
  if (wasOpen && providerSettingsReturnFocus?.isConnected) {
    providerSettingsReturnFocus.focus();
  }
  providerSettingsReturnFocus = null;
}

function renderProviderCredentials(statuses) {
  for (const status of statuses) {
    const row = document.querySelector(`.provider-row[data-provider="${status.provider}"]`);
    if (!row) continue;
    const state = row.querySelector('.provider-state');
    const model = row.querySelector('.provider-model');
    const remove = row.querySelector('.provider-delete');
    if (state) {
      state.textContent = status.configured
        ? `已配置 ${status.key_hint || ''}`.trim()
        : '未配置';
      state.classList.toggle('configured', status.configured);
    }
    if (model && status.model) model.value = status.model;
    if (remove) remove.disabled = status.source !== 'personal';
  }
}

function providerCatalogTimestamp(value) {
  if (!value) return '';
  const parsed = new Date(value);
  if (Number.isNaN(parsed.getTime())) return '';
  return parsed.toLocaleString('zh-CN', { hour12: false });
}

function renderProviderModelCatalogs(catalogs) {
  const groupDefinitions = [
    ['latest', '最新推荐'],
    ['quality', '质量优先'],
    ['balanced', '均衡'],
    ['economy', '低成本 / 高速'],
    ['specialized', '专项模型'],
    ['legacy', '兼容旧版'],
    ['account', '账号可用'],
  ];
  for (const catalog of catalogs) {
    const row = document.querySelector(`.provider-row[data-provider="${catalog.provider}"]`);
    if (!row) continue;
    const select = row.querySelector('.provider-model');
    if (!select) continue;
    const selected = catalog.selected_model || select.value || catalog.default_model;
    const models = [...new Set([selected, ...(catalog.models || [])].filter(Boolean))];
    const guidance = new Map(
      (catalog.model_options || []).map(option => [option.id, option])
    );
    const groupedModels = new Map(groupDefinitions.map(([id]) => [id, []]));
    for (const model of models) {
      const metadata = guidance.get(model) || {
        id: model,
        group: 'account',
        description: '当前账号可用',
      };
      const group = groupedModels.has(metadata.group) ? metadata.group : 'account';
      groupedModels.get(group).push({ ...metadata, id: model });
    }
    const groups = groupDefinitions.flatMap(([groupId, groupLabel]) => {
      const entries = groupedModels.get(groupId);
      if (!entries.length) return [];
      const group = document.createElement('optgroup');
      group.label = groupLabel;
      group.replaceChildren(...entries.map(metadata => {
        const option = document.createElement('option');
        option.value = metadata.id;
        option.textContent = metadata.description
          ? `${metadata.id} · ${metadata.description}`
          : metadata.id;
        option.title = metadata.description || metadata.id;
        return option;
      }));
      return [group];
    });
    select.replaceChildren(...groups);
    select.value = selected;

    const refreshed = providerCatalogTimestamp(catalog.refreshed_at);
    const verified = catalog.catalog_verified_on
      ? `内置目录核对 ${catalog.catalog_verified_on}`
      : '';
    const meta = row.querySelector('.provider-model-meta');
    if (meta) {
      meta.textContent = catalog.warning || (
        refreshed ? `账号模型更新 ${refreshed}` : verified
      );
    }
    const refresh = row.querySelector('.provider-model-refresh');
    if (refresh) {
      refresh.title = [
        catalog.warning || `${catalog.label} 模型列表：${catalog.source}`,
        verified,
        refreshed ? `账号模型更新 ${refreshed}` : '',
      ].filter(Boolean).join('；');
    }
  }
}

async function refreshProviderCredentials() {
  const error = document.getElementById('provider-settings-error');
  if (error) error.textContent = '';
  try {
    const [catalogs, statuses] = await Promise.all([
      api.listProviderModels(),
      api.listProviderCredentials(),
    ]);
    renderProviderModelCatalogs(catalogs);
    renderProviderCredentials(statuses);
  } catch (err) {
    if (error) error.textContent = err.message;
  }
}

async function showProviderSettings() {
  const modal = document.getElementById('provider-settings-modal');
  const username = localStorage.getItem('paperChinaUsername') || '本地管理员';
  const user = document.getElementById('provider-settings-user');
  if (user) user.textContent = username;
  providerSettingsReturnFocus = document.activeElement;
  modal?.classList.remove('hidden');
  focusableElements(modal)[0]?.focus();
  await refreshProviderCredentials();
}

async function saveProviderCredential(e) {
  const row = e.target.closest('.provider-row');
  if (!row) return;
  const provider = row.dataset.provider;
  const keyInput = row.querySelector('.provider-key');
  const modelInput = row.querySelector('.provider-model');
  const button = e.target;
  const payload = { model: modelInput?.value.trim() || null };
  if (keyInput?.value.trim()) payload['api_key'] = keyInput.value.trim();
  button.disabled = true;
  try {
    const status = await api.saveProviderCredential(provider, payload);
    keyInput.value = '';
    renderProviderCredentials([status]);
    toastSuccess(`${status.label} API 配置已保存`);
    api.refreshProviderModels(provider)
      .then(catalog => {
        renderProviderModelCatalogs([catalog]);
        if (catalog.warning) toastError(catalog.warning);
      })
      .catch(err => toastError(err.message));
  } catch (err) {
    toastError(err.message);
  } finally {
    button.disabled = false;
  }
}

async function refreshProviderModelsForRow(e) {
  const row = e.target.closest('.provider-row');
  if (!row) return;
  const button = e.target;
  button.disabled = true;
  try {
    const catalog = await api.refreshProviderModels(row.dataset.provider);
    renderProviderModelCatalogs([catalog]);
    if (catalog.warning) toastError(catalog.warning);
    else toastSuccess(`${catalog.label} 模型列表已更新`);
  } catch (err) {
    toastError(err.message);
  } finally {
    button.disabled = false;
  }
}

async function deleteProviderCredential(e) {
  const row = e.target.closest('.provider-row');
  if (!row) return;
  const button = e.target;
  button.disabled = true;
  try {
    await api.deleteProviderCredential(row.dataset.provider);
    await refreshProviderCredentials();
    toastSuccess('个人 API 配置已删除');
  } catch (err) {
    toastError(err.message);
  } finally {
    button.disabled = false;
  }
}

// === Views ===
function showView(name) {
  // Clean up polling when leaving reader
  if (name !== 'reader' && translationPollPaperId) {
    if (translationPollId) clearInterval(translationPollId);
    translationPollId = null;
    translationPollPaperId = null;
    translationPollGeneration++;
    document.getElementById('translation-progress')?.classList.add('hidden');
  }
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  document.getElementById(`${name}-view`).classList.add('active');
}

function showLibrary() {
  showView('library');
  loadPapers();
}

function showUpload() {
  showView('upload');
  selectedFiles = [];
  selectedFileKeys.clear();
  document.getElementById('upload-preview').classList.add('hidden');
  document.getElementById('upload-progress').classList.add('hidden');
  document.getElementById('drop-zone').classList.remove('hidden');
  document.getElementById('file-input').value = '';
  const tags = document.getElementById('upload-tags');
  if (tags) tags.value = '';
}

// === Paper Library ===
async function loadPapers() {
  const search = document.getElementById('search-input').value;
  const status = document.getElementById('status-filter').value;
  const tag = document.getElementById('tag-filter')?.value || '';
  const skeleton = document.getElementById('loading-skeleton');
  const paperList = document.getElementById('paper-list');

  // Show skeleton on first load
  if (skeleton && paperList && paperList.children.length === 0) {
    skeleton.classList.remove('hidden');
  }

  try {
    const data = await api.listPapers(search, status, tag, pagination.offset, pagination.limit);
    papers = data.papers;
    pagination.total = data.total;
    renderPaperList();
    renderPagination();
    updateStats();
  } catch (e) {
    console.error('Failed to load papers:', e);
    const container = document.getElementById('paper-list');
    if (container) container.innerHTML = '<div class="empty-state"><p style="color:var(--error)">加载失败</p><button class="btn btn-primary" onclick="loadPapers()">重试</button></div>';
  } finally {
    // Hide skeleton after data loads
    if (skeleton) skeleton.classList.add('hidden');
  }
}

async function updateStats() {
  try {
    const stats = await api.getStats();
    const statsEl = document.getElementById('stats-bar');
    if (statsEl) {
      statsEl.textContent = `${stats.total_papers} 篇论文 | ${stats.completed_translations} 已翻译`;
    }
  } catch (e) {
    // ignore
  }
}

let batchTranslating = false;

function getPreserveGraphicsTextOption() {
  const control = document.getElementById('preserve-graphics-text');
  return control ? control.checked : true;
}

async function batchTranslate() {
  if (batchTranslating) return;

  const pending = papers.filter(p => p.translation_status === 'pending' || p.translation_status === 'failed');
  if (pending.length === 0) {
    toastWarning('没有待翻译的论文');
    return;
  }

  if (!confirm(`确定翻译 ${pending.length} 篇论文？`)) return;

  batchTranslating = true;
  const quality = document.getElementById('quality-preset')?.value || 'balanced';
  const options = {
    preserve_graphics_text: getPreserveGraphicsTextOption(),
    skip_overflow: document.getElementById('skip-overflow')?.checked || false,
    qa_mode: document.getElementById('qa-mode')?.value || 'single',
    qa_max_passes: 4,
    ocr_mode: document.getElementById('ocr-mode')?.value || 'off',
  };

  try {
    // Submit all translations in parallel (server runs them in background)
    const results = await Promise.allSettled(
      pending.map(p => api.translatePaper(p.id, '', quality, options))
    );
    const success = results.filter(r => r.status === 'fulfilled').length;
    const failed = results.length - success;

    toastSuccess(`已提交 ${success} 篇翻译任务${failed > 0 ? `，${failed} 篇提交失败` : ''}。翻译在后台进行中。`);
    loadPapers();
  } finally {
    batchTranslating = false;
  }
}

function debounceSearch() {
  clearTimeout(searchTimer);
  searchTimer = setTimeout(loadPapers, 300);
}

function renderPaperList() {
  const container = document.getElementById('paper-list');
  const empty = document.getElementById('empty-state');

  if (papers.length === 0) {
    container.innerHTML = '';
    empty.classList.remove('hidden');
    return;
  }
  empty.classList.add('hidden');

  container.innerHTML = papers.map(p => `
    <article class="paper-card" data-paper-id="${esc(p.id)}" data-action="open-reader">
      <h2 class="title"><button type="button" class="paper-card-link" data-action="open-reader" data-paper-id="${esc(p.id)}" title="${esc(p.title)}" aria-label="打开论文：${esc(p.title)}">${esc(p.title)}</button></h2>
      <div class="meta">
        <span>${p.page_count} 页</span>
        <span>${formatSize(p.file_size)}</span>
        <span>${formatDate(p.created_at)}</span>
      </div>
      <span class="status status-${sanitizeClass(p.translation_status)}">${statusLabel(p.translation_status)}</span>
      ${p.translation_status === 'translating' ? `
        <div class="progress-bar" style="margin-top:8px" role="progressbar" aria-label="${esc(p.title)} 翻译进度" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${Math.round(p.translation_progress * 100)}">
          <div class="progress-fill" style="width:${Math.round(p.translation_progress * 100)}%"></div>
        </div>
      ` : ''}
      ${p.translation_status === 'completed' ? `
        <div class="meta" style="margin-top:4px;color:var(--success)">✓ 翻译完成 ${formatDate(p.updated_at)}</div>
      ` : ''}
      ${p.translation_status === 'failed' && p.translation_error ? `
        <div class="meta" style="margin-top:4px;color:var(--error);font-size:11px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${esc(p.translation_error)}">⚠ ${esc(p.translation_error)}</div>
      ` : ''}
      ${p.translation_status === 'repairing' ? `
        <div class="meta" style="margin-top:4px;color:var(--warning);font-size:11px" title="${esc(p.translation_error || '')}">任务已停止，不占用翻译队列；已保留最佳译文，修复发布后自动重试</div>
      ` : ''}
      ${p.tags ? `<div class="meta tags-row" style="margin-top:6px"><span aria-hidden="true">🏷</span> ${p.tags.split(',').map(t => `<button type="button" class="tag-chip" data-action="filter-by-tag" data-tag="${esc(t.trim())}">${esc(t.trim())}</button>`).join(' ')}</div>` : ''}
      <div class="actions" data-action="stop-propagation">
        ${p.translation_status === 'pending' || p.translation_status === 'failed' ?
          `<button class="btn btn-sm btn-primary" data-action="quick-translate" data-paper-id="${esc(p.id)}">翻译</button>` : ''}
        ${p.has_translated ?
          `<button class="btn btn-sm btn-outline" data-action="download-translated-by-id" data-paper-id="${esc(p.id)}">译文</button>` : ''}
        ${p.has_dual ?
          `<button class="btn btn-sm btn-outline" data-action="download-dual-by-id" data-paper-id="${esc(p.id)}">双语</button>` : ''}
        <button class="btn btn-sm btn-outline" data-action="confirm-delete" data-paper-id="${esc(p.id)}" data-paper-title="${esc(p.title)}">删除</button>
      </div>
    </article>
  `).join('');
}

function renderPagination() {
  const container = document.getElementById('pagination');
  if (!container) return;

  const totalPages = Math.ceil(pagination.total / pagination.limit);
  const currentPage = Math.floor(pagination.offset / pagination.limit) + 1;

  if (totalPages <= 1) {
    container.innerHTML = '';
    return;
  }

  let html = '<div class="pagination-controls">';
  if (currentPage > 1) {
    html += `<button class="btn btn-sm btn-outline" data-action="go-to-page" data-page="${currentPage - 1}">上一页</button>`;
  }
  html += `<span class="pagination-info">${currentPage} / ${totalPages} (${pagination.total} 篇)</span>`;
  if (currentPage < totalPages) {
    html += `<button class="btn btn-sm btn-outline" data-action="go-to-page" data-page="${currentPage + 1}">下一页</button>`;
  }
  html += '</div>';
  container.innerHTML = html;
}

function goToPage(page) {
  pagination.offset = (page - 1) * pagination.limit;
  loadPapers();
}

// === Upload ===
function savePendingUploadSessions() {
  localStorage.setItem(
    RESUMABLE_UPLOAD_STORAGE_KEY,
    JSON.stringify(Array.from(pendingUploadSessions.entries()))
  );
}

function createUploadId() {
  const bytes = crypto.getRandomValues(new Uint8Array(16));
  return Array.from(bytes, value => value.toString(16).padStart(2, '0')).join('');
}

async function sha256Hex(blob) {
  if (!crypto?.subtle) throw new Error('当前页面不支持安全分片校验，请使用 HTTPS 访问');
  const digest = await crypto.subtle.digest('SHA-256', await blob.arrayBuffer());
  return Array.from(new Uint8Array(digest), value => value.toString(16).padStart(2, '0')).join('');
}

async function uploadChunkWithRetry(uploadId, index, chunk, onProgress) {
  const sha256 = await sha256Hex(chunk);
  let lastError = null;
  for (let attempt = 1; attempt <= 3; attempt++) {
    try {
      return await api.uploadResumableChunk(
        uploadId,
        index,
        chunk,
        sha256,
        onProgress
      );
    } catch (error) {
      lastError = error;
      if (attempt < 3) {
        await new Promise(resolve => setTimeout(resolve, 400 * (2 ** (attempt - 1))));
      }
    }
  }
  throw lastError || new Error('分片上传失败');
}

async function completeUploadWithRetry(uploadId) {
  let lastError = null;
  for (let attempt = 1; attempt <= 3; attempt++) {
    try {
      return await api.completeResumableUpload(uploadId);
    } catch (error) {
      lastError = error;
      if (attempt < 3) {
        await new Promise(resolve => setTimeout(resolve, 500 * attempt));
      }
    }
  }
  throw lastError || new Error('无法确认上传结果');
}

async function getOrCreateResumableUpload(file, tags) {
  const key = uploadFileKey(file);
  let uploadId = pendingUploadSessions.get(key) || '';
  if (uploadId) {
    try {
      const existing = await api.getResumableUpload(uploadId);
      if (existing.filename === file.name && existing.file_size === file.size) return existing;
      pendingUploadSessions.delete(key);
      savePendingUploadSessions();
      uploadId = '';
    } catch (error) {
      if (error.status !== 404) throw error;
      pendingUploadSessions.delete(key);
      savePendingUploadSessions();
      uploadId = '';
    }
  }
  if (!uploadId) {
    uploadId = createUploadId();
    pendingUploadSessions.set(key, uploadId);
    savePendingUploadSessions();
  }
  return api.initResumableUpload(file, tags, uploadId);
}

async function uploadPaperResumable(file, tags, onProgress) {
  const key = uploadFileKey(file);
  const session = await getOrCreateResumableUpload(file, tags);
  if (session.paper_id) {
    const paper = await completeUploadWithRetry(session.upload_id);
    pendingUploadSessions.delete(key);
    savePendingUploadSessions();
    onProgress(1);
    return paper;
  }

  const uploaded = new Set(session.uploaded_chunks || []);
  const chunkLength = index => Math.min(
    session.chunk_size,
    file.size - index * session.chunk_size
  );
  let completedBytes = Array.from(uploaded).reduce(
    (total, index) => total + chunkLength(index),
    0
  );
  onProgress(completedBytes / file.size);
  for (let index = 0; index < session.chunk_count; index++) {
    if (uploaded.has(index)) continue;
    const start = index * session.chunk_size;
    const chunk = file.slice(start, start + session.chunk_size);
    await uploadChunkWithRetry(session.upload_id, index, chunk, sentBytes => {
      onProgress(Math.min(1, (completedBytes + sentBytes) / file.size));
    });
    completedBytes += chunk.size;
    onProgress(Math.min(1, completedBytes / file.size));
  }

  const paper = await completeUploadWithRetry(session.upload_id);
  pendingUploadSessions.delete(key);
  savePendingUploadSessions();
  onProgress(1);
  return paper;
}

function initDropZone() {
  const zone = document.getElementById('drop-zone');
  if (!zone) return;
  zone.addEventListener('dragover', e => { e.preventDefault(); zone.classList.add('dragover'); });
  zone.addEventListener('dragleave', () => zone.classList.remove('dragover'));
  zone.addEventListener('drop', e => {
    e.preventDefault();
    zone.classList.remove('dragover');
    const files = Array.from(e.dataTransfer.files).filter(f => f.name.toLowerCase().endsWith('.pdf'));
    if (files.length > 0) addFiles(files);
  });
}

function handleFileSelect(input) {
  const files = Array.from(input.files).filter(f => f.name.toLowerCase().endsWith('.pdf'));
  if (files.length > 0) addFiles(files);
  input.value = '';
}

function uploadFileKey(file) {
  return `${file.name}:${file.size}:${file.lastModified || 0}`;
}

function addFiles(files) {
  const maxSize = 100 * 1024 * 1024;
  let duplicates = 0;
  for (const f of files) {
    if (f.size > maxSize) { toastWarning(`${f.name} 过大（最大 100MB）`); continue; }
    if (f.size === 0) { toastWarning(`${f.name} 为空`); continue; }
    const key = uploadFileKey(f);
    if (selectedFileKeys.has(key)) {
      duplicates++;
      continue;
    }
    selectedFileKeys.add(key);
    selectedFiles.push(f);
  }
  if (duplicates > 0) {
    toastWarning(`已跳过 ${duplicates} 个重复文件`);
  }
  if (selectedFiles.length === 0) return;
  document.getElementById('drop-zone').classList.remove('hidden');
  document.getElementById('upload-preview').classList.remove('hidden');
  renderFileList();
}

function renderFileList() {
  const container = document.getElementById('file-list');
  const summary = document.getElementById('upload-summary');
  const totalSize = selectedFiles.reduce((sum, file) => sum + file.size, 0);
  if (summary) {
    summary.textContent = `${selectedFiles.length} 篇待上传 · ${formatSize(totalSize)}`;
  }
  container.innerHTML = selectedFiles.map((f, i) => `
    <div class="file-item">
      <span class="file-item-name">${esc(f.name)}</span>
      <span class="file-item-size">${formatSize(f.size)}</span>
      <button class="file-item-remove" data-action="remove-file" data-index="${i}" title="移除">&times;</button>
    </div>
  `).join('');
  const btn = document.getElementById('btn-do-upload');
  btn.textContent = selectedFiles.length > 1 ? `确认上传 ${selectedFiles.length} 篇` : '确认上传';
}

function removeFile(index) {
  const removed = selectedFiles.splice(index, 1)[0];
  if (removed) {
    const key = uploadFileKey(removed);
    selectedFileKeys.delete(key);
    pendingUploadSessions.delete(key);
    savePendingUploadSessions();
  }
  if (selectedFiles.length === 0) {
    cancelUpload();
  } else {
    renderFileList();
  }
}

function cancelUpload() {
  for (const file of selectedFiles) pendingUploadSessions.delete(uploadFileKey(file));
  savePendingUploadSessions();
  selectedFiles = [];
  selectedFileKeys.clear();
  document.getElementById('drop-zone').classList.remove('hidden');
  document.getElementById('upload-preview').classList.add('hidden');
  document.getElementById('upload-progress').classList.add('hidden');
  document.getElementById('file-input').value = '';
}

let uploading = false;

function setProgressValue(fill, percent) {
  if (!fill) return;
  const value = Math.max(0, Math.min(100, Math.round(Number(percent) || 0)));
  fill.style.width = `${value}%`;
  fill.closest('[role="progressbar"]')?.setAttribute('aria-valuenow', String(value));
}

async function doUpload() {
  if (selectedFiles.length === 0 || uploading) return;
  uploading = true;
  const filesToUpload = [...selectedFiles];

  const tags = document.getElementById('upload-tags').value;
  const prog = document.getElementById('upload-progress');
  const fill = document.getElementById('upload-progress-fill');
  const status = document.getElementById('upload-status');

  document.getElementById('drop-zone').classList.add('hidden');
  document.getElementById('upload-preview').classList.add('hidden');
  prog.classList.remove('hidden');

  let success = 0;
  let failed = 0;
  const failedFiles = [];
  const total = filesToUpload.length;

  for (let i = 0; i < total; i++) {
    const file = filesToUpload[i];
    setProgressValue(fill, 0);
    fill.style.background = '';
    status.textContent = `上传中 (${i + 1}/${total}): ${file.name}`;

    try {
      const upload = file.size >= RESUMABLE_UPLOAD_THRESHOLD
        ? uploadPaperResumable
        : (smallFile, smallTags, onProgress) => (
            api.uploadPaperWithProgress(smallFile, smallTags, onProgress)
          );
      await upload(file, tags, pct => {
        setProgressValue(fill, pct * 100);
      });
      success++;
    } catch (e) {
      failed++;
      failedFiles.push(file);
      toastError(`${file.name} 上传失败: ${e.message}`);
    }
  }

  setProgressValue(fill, 100);
  fill.style.background = failed > 0 ? 'var(--warning)' : 'var(--success)';
  status.textContent = `完成！${success} 篇成功${failed > 0 ? `，${failed} 篇失败` : ''}`;
  if (success > 0) {
    toastSuccess(`上传完成：${success} 篇成功${failed > 0 ? `，${failed} 篇待重试` : ''}`);
  }
  selectedFiles = failedFiles;
  selectedFileKeys = new Set(failedFiles.map(uploadFileKey));
  if (failedFiles.length > 0) {
    setTimeout(() => {
      prog.classList.add('hidden');
      document.getElementById('drop-zone').classList.remove('hidden');
      document.getElementById('upload-preview').classList.remove('hidden');
      renderFileList();
    }, 800);
  } else {
    selectedFileKeys.clear();
    setTimeout(() => showLibrary(), 1000);
  }
  uploading = false;
}

// === Reader (PDF.js with Virtual Scrolling) ===
let syncScrollEnabled = true;
let pdfDocs = { original: null, translated: null };
let pageMetrics = { original: [], translated: [] }; // cached {top, height} per page
let renderedPages = { original: new Set(), translated: new Set() };
let pageWrappers = { original: [], translated: [] };
let renderObservers = { original: null, translated: null };
let scrollListeners = { original: null, translated: null };
let activeRenderTasks = { original: new Map(), translated: new Map() };
const RENDER_SCALE = 1.5;
const MIN_SCALE = 0.5;
const MAX_SCALE = 3.0;
const MAX_CANVAS_DPR = 1.5;
const OVERSCAN_PX = 320;
const PAGE_GAP_PX = 4;

function availablePdfWidth(container) {
  return Math.max(320, (container?.clientWidth || 0) - 20);
}

function getRenderScale(panel) {
  const container = document.getElementById(`pdf-container-${panel}`);
  if (!container) return RENDER_SCALE;
  const containerWidth = availablePdfWidth(container);
  const metrics = pageMetrics[panel];
  if (!metrics || metrics.length === 0) return RENDER_SCALE;
  // Scale so the widest page fits the container
  const maxPageWidth = Math.max(...metrics.map(m => m.width / RENDER_SCALE));
  const fitScale = containerWidth / maxPageWidth;
  return Math.max(MIN_SCALE, Math.min(MAX_SCALE, fitScale));
}

function scheduleIdleWork(callback, timeout = 500) {
  if ('requestIdleCallback' in window) {
    window.requestIdleCallback(callback, { timeout });
  } else {
    setTimeout(callback, 0);
  }
}

function buildPageMetricsFromFirstPage(pdf, firstViewport, adaptiveScale) {
  const scaleRatio = adaptiveScale / RENDER_SCALE;
  const width = firstViewport.width * scaleRatio;
  const height = firstViewport.height * scaleRatio;
  const metrics = [];
  for (let i = 0; i < pdf.numPages; i++) {
    metrics.push({
      top: i === 0 ? 0 : metrics[i - 1].top + metrics[i - 1].height + PAGE_GAP_PX,
      height,
      width,
      baseWidth: firstViewport.width,
      baseHeight: firstViewport.height,
      pageNum: i + 1,
    });
  }
  metrics._adaptiveScale = adaptiveScale;
  metrics._baseScale = RENDER_SCALE;
  return metrics;
}

function updatePageWrapperSizes(panel) {
  const metrics = pageMetrics[panel];
  const wrappers = pageWrappers[panel];
  if (!metrics?.length || !wrappers?.length) return;
  for (let i = 0; i < metrics.length; i++) {
    if (!wrappers[i]) continue;
    wrappers[i].style.width = metrics[i].width + 'px';
    wrappers[i].style.height = metrics[i].height + 'px';
  }
}

async function refinePdfMetrics(panel, pdf, adaptiveScale) {
  const metrics = pageMetrics[panel];
  if (!metrics?.length) return;
  const scaleRatio = adaptiveScale / RENDER_SCALE;
  let changed = false;

  for (let i = 2; i <= pdf.numPages; i++) {
    if (pdfDocs[panel] !== pdf) return;
    const page = await pdf.getPage(i);
    const viewport = page.getViewport({ scale: RENDER_SCALE });
    const metric = metrics[i - 1];
    const width = viewport.width * scaleRatio;
    const height = viewport.height * scaleRatio;
    if (Math.abs(metric.width - width) > 1 || Math.abs(metric.height - height) > 1) {
      metric.baseWidth = viewport.width;
      metric.baseHeight = viewport.height;
      metric.width = width;
      metric.height = height;
      changed = true;
    }
    if (i % 8 === 0) {
      await new Promise(resolve => setTimeout(resolve, 0));
    }
  }

  if (!changed || pdfDocs[panel] !== pdf) return;
  for (let i = 0; i < metrics.length; i++) {
    metrics[i].top = i === 0 ? 0 : metrics[i - 1].top + metrics[i - 1].height + PAGE_GAP_PX;
  }
  updatePageWrapperSizes(panel);
}

// Whalent's forwarded preview can reject direct Worker requests even though
// credentialed page requests succeed. Fetch the vendored worker first and run
// it from a Blob so the preview credential stays on the main-thread request.
let pdfWorkerReady = Promise.resolve();
let pdfLibraryReady = null;
let pdfWorkerConfigured = false;

function resolvePdfWorkerSrc() {
  const appScript = document.currentScript
    || Array.from(document.scripts).find(script => script.src.includes('/static/js/app.js'));
  const appSrc = appScript?.src || new URL('/static/js/app.js', window.location.origin).href;
  return new URL('pdf.worker.min.js', appSrc).href;
}

function isWhalentForwardedPreview() {
  return window.location.hostname.endsWith('.fwd.memory.whalent.com');
}

function preloadPdfWorkerOnMainThread(workerSrc) {
  if (globalThis.pdfjsWorker?.WorkerMessageHandler) return Promise.resolve();
  return new Promise((resolve, reject) => {
    const script = document.createElement('script');
    script.src = workerSrc;
    script.async = true;
    script.dataset.pdfWorkerFallback = 'main-thread';
    script.addEventListener('load', () => {
      if (globalThis.pdfjsWorker?.WorkerMessageHandler) resolve();
      else reject(new Error('PDF worker script loaded without WorkerMessageHandler'));
    }, { once: true });
    script.addEventListener('error', () => {
      reject(new Error(`Cannot load PDF worker script: ${workerSrc}`));
    }, { once: true });
    document.head.appendChild(script);
  });
}

async function prepareForwardedPdfWorker(workerSrc) {
  try {
    const response = await fetch(workerSrc, {
      credentials: 'include',
      cache: 'no-store',
    });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);

    const workerBlob = await response.blob();
    const workerUrl = URL.createObjectURL(workerBlob);
    try {
      pdfjsLib.GlobalWorkerOptions.workerPort = new Worker(workerUrl);
      return;
    } finally {
      URL.revokeObjectURL(workerUrl);
    }
  } catch (error) {
    console.warn('Blob PDF worker unavailable; using the main-thread fallback.', error);
  }

  await preloadPdfWorkerOnMainThread(workerSrc);
}

function configurePdfLibrary() {
  if (typeof pdfjsLib === 'undefined') {
    throw new Error('PDF 阅读器资源未加载');
  }
  if (pdfWorkerConfigured) return pdfWorkerReady;
  pdfWorkerConfigured = true;
  const pdfWorkerSrc = resolvePdfWorkerSrc();
  pdfjsLib.GlobalWorkerOptions.workerSrc = pdfWorkerSrc;
  if (isWhalentForwardedPreview()) {
    pdfWorkerReady = prepareForwardedPdfWorker(pdfWorkerSrc);
  }
  return pdfWorkerReady;
}

function ensurePdfLibrary() {
  if (typeof pdfjsLib !== 'undefined') {
    if (!pdfLibraryReady) pdfLibraryReady = Promise.resolve(configurePdfLibrary());
    return pdfLibraryReady;
  }
  if (pdfLibraryReady) return pdfLibraryReady;
  pdfLibraryReady = new Promise((resolve, reject) => {
    const script = document.createElement('script');
    script.src = new URL('pdf.min.js', resolvePdfWorkerSrc()).href;
    script.async = true;
    script.dataset.pdfLibrary = 'lazy';
    script.addEventListener('load', () => {
      Promise.resolve(configurePdfLibrary()).then(resolve, reject);
    }, { once: true });
    script.addEventListener('error', () => {
      pdfLibraryReady = null;
      reject(new Error(`Cannot load PDF reader script: ${script.src}`));
    }, { once: true });
    document.head.appendChild(script);
  });
  return pdfLibraryReady;
}

// === Reader display mode (pdf.js vs per-page images) ===
// The public tunnel can drop to ~100-400KB/s; pdf.js range requests on a
// 10MB+ PDF feel broken at that speed, while a ~150KB page JPEG is fine.
// Mode: 'auto' (probe once per session) | 'pdf' | 'image', persisted.
let readerModePreference = localStorage.getItem('paperChinaReaderMode') || 'auto';
let sessionSlowConnection = null;

async function detectSlowConnection() {
  if (sessionSlowConnection !== null) return sessionSlowConnection;
  try {
    const t0 = performance.now();
    const res = await fetch('/static/js/app.js', { cache: 'no-store' });
    const buf = await res.arrayBuffer();
    const secs = Math.max((performance.now() - t0) / 1000, 0.001);
    sessionSlowConnection = (buf.byteLength / secs) < 400 * 1024;
  } catch {
    sessionSlowConnection = false;
  }
  return sessionSlowConnection;
}

function effectiveReaderMode() {
  if (readerModePreference !== 'auto') return readerModePreference;
  return sessionSlowConnection ? 'image' : 'pdf';
}

function updateReaderModeButton() {
  const btn = document.getElementById('btn-reader-mode');
  if (!btn) return;
  const mode = effectiveReaderMode();
  btn.textContent = mode === 'image' ? '极速模式: 开' : '极速模式: 关';
  btn.title = mode === 'image'
    ? '当前为页图模式（慢速网络优化），点击切换到 PDF 原文模式'
    : '当前为 PDF 模式，点击切换到页图模式（慢速网络更快）';
}

function toggleReaderMode() {
  const current = effectiveReaderMode();
  readerModePreference = current === 'image' ? 'pdf' : 'image';
  localStorage.setItem('paperChinaReaderMode', readerModePreference);
  updateReaderModeButton();
  if (currentPaper) openReader(currentPaper.id);
}

async function loadPanelDocument(panel, loadId) {
  if (effectiveReaderMode() === 'image') {
    return loadImageDocument(panel, loadId);
  }
  return loadPdfDocument(panel, `/api/papers/${currentPaper.id}/view/${panel}`, loadId);
}

function refreshImagePageMetrics(panel) {
  const wrappers = pageWrappers[panel];
  if (!wrappers?.length) return;
  const metrics = [];
  let top = 0;
  for (let i = 0; i < wrappers.length; i++) {
    const wrapper = wrappers[i];
    const height = Math.max(1, wrapper.offsetHeight || 800);
    metrics.push({
      top,
      height,
      width: Math.max(1, wrapper.offsetWidth || 1),
      pageNum: i + 1,
    });
    top += height + PAGE_GAP_PX;
  }
  pageMetrics[panel] = metrics;
}

async function loadImageDocument(panel, loadId = currentLoadId) {
  const container = document.getElementById(`pdf-container-${panel}`);
  container.textContent = '';
  const pageCount = currentPaper.page_count || 1;
  const wrappers = [];
  for (let i = 0; i < pageCount; i++) {
    const wrapper = document.createElement('div');
    wrapper.className = 'pdf-page-wrapper';
    wrapper.style.minHeight = '800px';
    wrapper.dataset.pageIdx = i;
    wrapper.innerHTML = '<div class="pdf-page-loading">加载中...</div>';
    container.appendChild(wrapper);
    wrappers.push(wrapper);
  }
  pageWrappers[panel] = wrappers;
  refreshImagePageMetrics(panel);
  const observer = new IntersectionObserver((entries) => {
    for (const entry of entries) {
      if (!entry.isIntersecting) continue;
      observer.unobserve(entry.target);
      loadPreviewImage(panel, entry.target, loadId);
    }
  }, { root: container, rootMargin: '600px' });
  wrappers.forEach((w) => observer.observe(w));
  if (renderObservers[panel]) renderObservers[panel].disconnect();
  renderObservers[panel] = observer;
  updatePageInfo(panel, container.scrollTop);
  setupSmoothScrollSync(panel);
}

function loadPreviewImage(panel, wrapper, loadId) {
  if (wrapper._previewLoadId === loadId && wrapper._previewLoadPromise) {
    return wrapper._previewLoadPromise;
  }
  wrapper._previewLoadId = loadId;
  wrapper._previewLoadPromise = loadPreviewImageOnce(panel, wrapper, loadId)
    .catch(() => {
      wrapper.innerHTML = '<div class="pdf-page-loading">本页加载失败</div>';
      wrapper._previewLoadPromise = null;
    });
  return wrapper._previewLoadPromise;
}

async function loadPreviewImageOnce(panel, wrapper, loadId) {
  const page = parseInt(wrapper.dataset.pageIdx, 10) + 1;
  const res = await apiFetch(`/api/papers/${currentPaper.id}/preview/${panel}/${page}`);
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const blob = await res.blob();
  if (loadId !== currentLoadId) return;
  const url = URL.createObjectURL(blob);
  try {
    const img = document.createElement('img');
    img.alt = `第 ${page} 页`;
    img.style.width = '100%';
    img.style.display = 'block';
    const imageLoaded = new Promise((resolve, reject) => {
      img.onload = () => resolve();
      img.onerror = () => reject(new Error('preview image failed to decode'));
    });
    wrapper.textContent = '';
    wrapper.appendChild(img);
    img.src = url;
    await imageLoaded;
    if (loadId !== currentLoadId) return;
    wrapper.style.minHeight = '';
    await new Promise(resolve => requestAnimationFrame(resolve));
    refreshImagePageMetrics(panel);
  } finally {
    URL.revokeObjectURL(url);
  }
}

async function openReader(paperId) {
  // Cancel any ongoing load
  const loadId = ++currentLoadId;
  resetScrollSyncScheduling();
  for (const panel of ['original', 'translated']) {
    const oldContainer = document.getElementById(`pdf-container-${panel}`);
    if (oldContainer && scrollListeners[panel]) {
      oldContainer.removeEventListener('scroll', scrollListeners[panel]);
      scrollListeners[panel] = null;
    }
    if (renderObservers[panel]) {
      renderObservers[panel].disconnect();
      renderObservers[panel] = null;
    }
  }
  if (translationPollPaperId && translationPollPaperId !== paperId) {
    if (translationPollId) clearInterval(translationPollId);
    translationPollId = null;
    translationPollPaperId = null;
    translationPollGeneration++;
    document.getElementById('translation-progress')?.classList.add('hidden');
  }
  for (const panel of ['original', 'translated']) {
    for (const state of activeRenderTasks[panel].values()) {
      const renderTask = state.renderTask;
      if (renderTask) {
        try { renderTask.cancel(); } catch { /* already complete */ }
      }
    }
  }
  activeRenderTasks = { original: new Map(), translated: new Map() };

  // Show loading state immediately
  showView('reader');
  window.scrollTo({ top: 0, left: 0, behavior: 'auto' });
  document.getElementById('reader-title').textContent = '加载中...';
  for (const panel of ['original', 'translated']) {
    const container = document.getElementById(`pdf-container-${panel}`);
    if (container) {
      container.innerHTML = '<div style="color:#aaa;padding:40px;text-align:center;">加载中...</div>';
    }
  }

  try {
    currentPaper = await api.getPaper(paperId);
  } catch (e) {
    toastError('无法加载论文');
    showLibrary();
    return;
  }

  // If a newer load started, abort this one
  if (loadId !== currentLoadId) return;

  document.getElementById('reader-title').textContent = currentPaper.title;
  hideQaReportPanel();
  hideEditableFiguresPanel();

  const placeholder = document.getElementById('translate-placeholder');
  const qaReportBtn = document.getElementById('btn-qa-report');
  if (qaReportBtn) {
    qaReportBtn.classList.toggle('hidden', !currentPaper.has_qa_report);
  }

  // Clean up previous observers and scroll listeners
  if (renderObservers.original) renderObservers.original.disconnect();
  if (renderObservers.translated) renderObservers.translated.disconnect();
  for (const panel of ['original', 'translated']) {
    const el = document.getElementById(`pdf-container-${panel}`);
    if (el && scrollListeners[panel]) {
      el.removeEventListener('scroll', scrollListeners[panel]);
      scrollListeners[panel] = null;
    }
  }
  pdfDocs = { original: null, translated: null };
  pageMetrics = { original: [], translated: [] };
  renderedPages = { original: new Set(), translated: new Set() };
  pageWrappers = { original: [], translated: [] };

  // Load original PDF first enough to show the first page quickly.
  await detectSlowConnection();
  updateReaderModeButton();
  await loadPanelDocument('original', loadId);
  if (loadId !== currentLoadId) return;

  const btnTranslate = document.getElementById('btn-translate');
  const btnRetranslate = document.getElementById('btn-retranslate');

  if (currentPaper.has_translated) {
    placeholder.classList.add('hidden');
    document.getElementById('pdf-container-translated').classList.remove('hidden');
    void loadPanelDocument('translated', loadId)
      .then(() => {
        if (loadId === currentLoadId) requestAnimationFrame(() => syncScrollFromPanel('original'));
      });
    document.getElementById('btn-download-mono').classList.remove('hidden');
    // A repair-pending job remains system-owned until it succeeds or the user
    // explicitly cancels it; do not offer a duplicate translation request.
    if (btnTranslate) btnTranslate.classList.add('hidden');
    if (btnRetranslate) {
      btnRetranslate.classList.toggle(
        'hidden',
        currentPaper.translation_status === 'repairing',
      );
    }
  } else {
    placeholder.classList.remove('hidden');
    document.getElementById('pdf-container-translated').classList.add('hidden');
    document.getElementById('btn-download-mono').classList.add('hidden');
    // Show translate button, hide re-translate button
    if (btnTranslate) btnTranslate.classList.remove('hidden');
    if (btnRetranslate) btnRetranslate.classList.add('hidden');

    // Show error details and retry button for failed translations
    const placeholderIcon = placeholder.querySelector('.placeholder-icon');
    const placeholderText = placeholder.querySelector('p');
    if (currentPaper.translation_status === 'failed') {
      if (placeholderIcon) placeholderIcon.textContent = '⚠️';
      if (placeholderText) {
        placeholderText.textContent = currentPaper.translation_error
          ? `翻译失败: ${currentPaper.translation_error}`
          : '翻译失败';
        placeholderText.style.color = 'var(--error)';
      }
    } else {
      if (placeholderIcon) placeholderIcon.textContent = '🌐';
      if (placeholderText) {
        placeholderText.textContent = '点击"翻译"按钮生成中文译文';
        placeholderText.style.color = '';
      }
    }
  }

  currentPaper.has_dual
    ? document.getElementById('btn-download-dual').classList.remove('hidden')
    : document.getElementById('btn-download-dual').classList.add('hidden');

  if (currentPaper.translation_status === 'translating') {
    pollTranslationStatus(paperId);
  }
}

async function loadPdfDocument(panel, url, loadId = currentLoadId) {
  const container = document.getElementById(`pdf-container-${panel}`);
  container.textContent = '';
  const loadingDiv = document.createElement('div');
  loadingDiv.style.cssText = 'color:#aaa;padding:20px;';
  loadingDiv.textContent = '加载中...';
  container.appendChild(loadingDiv);

  try {
    await ensurePdfLibrary();
    await pdfWorkerReady;
    if (loadId !== currentLoadId) return;
    const loadingTask = pdfjsLib.getDocument({ url, httpHeaders: authHeaders() });
    const pdf = await loadingTask.promise;
    if (loadId !== currentLoadId) return;
    pdfDocs[panel] = pdf;

    container.innerHTML = '';

    // Use the first page to build immediate placeholders. Remaining page sizes
    // are refined in the background so opening a PDF is not blocked by every page.
    const firstPage = await pdf.getPage(1);
    if (loadId !== currentLoadId) return;
    const firstViewport = firstPage.getViewport({ scale: RENDER_SCALE });

    // Calculate adaptive scale to fit container width
    const containerWidth = availablePdfWidth(container);
    const adaptiveScale = Math.max(MIN_SCALE, Math.min(MAX_SCALE, containerWidth / firstViewport.width * RENDER_SCALE));
    const metrics = buildPageMetricsFromFirstPage(pdf, firstViewport, adaptiveScale);
    pageMetrics[panel] = metrics;

    // Phase 2: Create placeholder wrappers with reserved height
    const wrappers = [];
    for (let i = 0; i < metrics.length; i++) {
      const wrapper = document.createElement('div');
      wrapper.className = 'pdf-page-wrapper';
      wrapper.style.width = metrics[i].width + 'px';
      wrapper.style.height = metrics[i].height + 'px';
      wrapper.style.flexShrink = '0';
      wrapper.dataset.pageIdx = i;
      wrapper.innerHTML = '<div class="pdf-page-loading">加载中...</div>';
      container.appendChild(wrapper);
      wrappers.push(wrapper);
    }
    pageWrappers[panel] = wrappers;

    // Phase 3: Set up intersection observer for lazy rendering
    const observer = new IntersectionObserver((entries) => {
      for (const entry of entries) {
        const idx = parseInt(entry.target.dataset.pageIdx);
        if (entry.isIntersecting) {
          void renderPage(panel, idx);
        }
      }
    }, {
      root: container,
      rootMargin: `${OVERSCAN_PX}px 0px ${OVERSCAN_PX}px 0px`
    });
    for (const wrapper of wrappers) {
      observer.observe(wrapper);
    }
    renderObservers[panel] = observer;

    updatePageInfo(panel, 0);
    await renderVisiblePages(panel, container, { awaitFirst: true, deferRest: true });
    scheduleIdleWork(() => {
      void refinePdfMetrics(panel, pdf, adaptiveScale);
    }, 1000);

    // Setup scroll sync
    setupSmoothScrollSync(panel);

  } catch (e) {
    container.textContent = '';
    const errDiv = document.createElement('div');
    errDiv.style.cssText = 'color:#f44336;padding:20px;';
    errDiv.textContent = '加载失败: ' + (e.message || '未知错误');
    container.appendChild(errDiv);
  }
}

async function renderVisiblePages(panel, container, options = {}) {
  const scrollTop = container.scrollTop;
  const viewBottom = scrollTop + container.clientHeight;
  const metrics = pageMetrics[panel];
  if (!metrics?.length) return;
  const indexes = [];

  for (let i = 0; i < metrics.length; i++) {
    const pageBottom = metrics[i].top + metrics[i].height;
    if (pageBottom >= scrollTop - OVERSCAN_PX && metrics[i].top <= viewBottom + OVERSCAN_PX) {
      indexes.push(i);
    }
  }

  if (options.awaitFirst && indexes.length > 0) {
    await renderPage(panel, indexes.shift());
  }
  for (const idx of indexes) {
    if (options.deferRest) {
      scheduleIdleWork(() => {
        void renderPage(panel, idx);
      }, 500);
    } else {
      await renderPage(panel, idx);
    }
  }
}

async function renderPage(panel, idx) {
  if (renderedPages[panel].has(idx)) return;
  const existing = activeRenderTasks[panel].get(idx);
  if (existing) return existing.promise;

  const pdf = pdfDocs[panel];
  if (!pdf) return;

  const wrapper = pageWrappers[panel][idx];
  if (!wrapper) return;
  const loadId = currentLoadId;
  const state = { renderTask: null, promise: null };
  state.promise = (async () => {
    try {
      const pageNum = pageMetrics[panel][idx].pageNum;
      const page = await pdf.getPage(pageNum);
      if (loadId !== currentLoadId || pdfDocs[panel] !== pdf || !wrapper.isConnected) return;

      const scale = pageMetrics[panel]._adaptiveScale || RENDER_SCALE;
      const viewport = page.getViewport({ scale });
      const canvas = document.createElement('canvas');
      const dpr = Math.min(window.devicePixelRatio || 1, MAX_CANVAS_DPR);
      canvas.width = Math.ceil(viewport.width * dpr);
      canvas.height = Math.ceil(viewport.height * dpr);
      canvas.style.width = viewport.width + 'px';
      canvas.style.height = viewport.height + 'px';

      const ctx = canvas.getContext('2d');
      ctx.scale(dpr, dpr);
      state.renderTask = page.render({ canvasContext: ctx, viewport });
      await state.renderTask.promise;
      if (loadId !== currentLoadId || pdfDocs[panel] !== pdf || !wrapper.isConnected) return;

      renderedPages[panel].add(idx);
      wrapper.innerHTML = '';
      wrapper.appendChild(canvas);
      const renderToken = `${Date.now()}-${Math.random()}`;
      wrapper.dataset.renderToken = renderToken;
      scheduleIdleWork(() => {
        if (
          loadId === currentLoadId
          && pdfDocs[panel] === pdf
          && wrapper.isConnected
          && renderedPages[panel].has(idx)
          && wrapper.dataset.renderToken === renderToken
        ) {
          void renderTextLayer(page, wrapper, viewport);
        }
      }, 300);
    } catch (error) {
      if (error?.name !== 'RenderingCancelledException') throw error;
    } finally {
      if (activeRenderTasks[panel].get(idx) === state) {
        activeRenderTasks[panel].delete(idx);
      }
    }
  })();
  activeRenderTasks[panel].set(idx, state);
  return state.promise;
}

async function renderTextLayer(page, wrapper, viewport) {
  if (typeof pdfjsLib.renderTextLayer !== 'function') return;

  const textLayer = document.createElement('div');
  textLayer.className = 'textLayer';
  textLayer.style.width = viewport.width + 'px';
  textLayer.style.height = viewport.height + 'px';
  textLayer.style.setProperty('--scale-factor', viewport.scale);
  wrapper.appendChild(textLayer);

  try {
    const textContent = await page.getTextContent();
    const renderTask = pdfjsLib.renderTextLayer({
      textContentSource: textContent,
      container: textLayer,
      viewport,
      textDivs: [],
    });
    if (renderTask?.promise) {
      await renderTask.promise;
    }
    textLayer.dataset.loaded = 'true';
  } catch (e) {
    console.warn('PDF text layer failed:', e);
    textLayer.remove();
  }
}

async function copyPdfSelection() {
  const selection = window.getSelection ? window.getSelection() : null;
  const selectedText = selection ? selection.toString().replace(/\s+\n/g, '\n').trim() : '';
  if (!selectedText) {
    toastInfo('请先选中 PDF 文本');
    return;
  }
  try {
    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(selectedText);
    } else {
      const textarea = document.createElement('textarea');
      textarea.value = selectedText;
      textarea.setAttribute('readonly', '');
      textarea.style.position = 'fixed';
      textarea.style.opacity = '0';
      document.body.appendChild(textarea);
      textarea.select();
      document.execCommand('copy');
      textarea.remove();
    }
    toastSuccess('已复制选中文本');
  } catch (e) {
    toastError('复制失败');
  }
}

// Scroll sync with page-based alignment
let scrollRafIds = { original: null, translated: null };
let syncRenderTimer = null;
let mirroredScrollTops = { original: null, translated: null };

function resetScrollSyncScheduling() {
  for (const panel of ['original', 'translated']) {
    if (scrollRafIds[panel]) cancelAnimationFrame(scrollRafIds[panel]);
    scrollRafIds[panel] = null;
  }
  if (syncRenderTimer) clearTimeout(syncRenderTimer);
  syncRenderTimer = null;
  mirroredScrollTops = { original: null, translated: null };
}

// Render the mirrored panel only after scrolling settles. Rendering PDF pages
// is CPU/GPU heavy; doing it on every scroll frame was the main cause of the
// laggy/unresponsive sync scrolling. The IntersectionObserver also renders
// newly visible pages, so this is mostly a fast-feedback safety net.
function scheduleOtherPanelRender(otherPanel, otherContainer) {
  if (syncRenderTimer) clearTimeout(syncRenderTimer);
  syncRenderTimer = setTimeout(() => {
    syncRenderTimer = null;
    void renderVisiblePages(otherPanel, otherContainer);
  }, 90);
}

function setupSmoothScrollSync(panel) {
  const container = document.getElementById(`pdf-container-${panel}`);

  const listener = () => {
    updatePageInfo(panel, container.scrollTop);
    if (!syncScrollEnabled) return;

    const mirroredTop = mirroredScrollTops[panel];
    if (mirroredTop !== null) {
      mirroredScrollTops[panel] = null;
      // Consume only the event caused by our own mirrored assignment. A
      // different position means the user moved this panel before that event
      // arrived, so the new gesture must become the synchronization source.
      if (Math.abs(container.scrollTop - mirroredTop) <= 1) return;
    }

    if (scrollRafIds[panel]) return;
    scrollRafIds[panel] = requestAnimationFrame(() => {
      scrollRafIds[panel] = null;
      syncScrollFromPanel(panel);
    });
  };
  container.addEventListener('scroll', listener, { passive: true });
  scrollListeners[panel] = listener;
}

function pageScrollPosition(panel, scrollTop) {
  const metrics = pageMetrics[panel];
  if (!metrics?.length) return { pageIdx: 0, fraction: 0 };

  let pageIdx = 0;
  const anchor = scrollTop + 20;
  for (let i = metrics.length - 1; i >= 0; i--) {
    if (metrics[i].top <= anchor) {
      pageIdx = i;
      break;
    }
  }

  const pageTop = metrics[pageIdx].top;
  const pageHeight = metrics[pageIdx].height;
  const fraction = pageHeight > 0
    ? Math.max(0, Math.min(1, (scrollTop - pageTop) / pageHeight))
    : 0;
  return { pageIdx, fraction };
}

function targetScrollTop(panel, pageIdx, fraction) {
  const metrics = pageMetrics[panel];
  if (!metrics?.length) return 0;
  const idx = Math.min(pageIdx, metrics.length - 1);
  const container = document.getElementById(`pdf-container-${panel}`);
  const rawScrollTop = metrics[idx].top + fraction * metrics[idx].height;
  if (!container) return rawScrollTop;
  const maxScrollTop = Math.max(0, container.scrollHeight - container.clientHeight);
  return Math.max(0, Math.min(maxScrollTop, rawScrollTop));
}

function syncScrollFromPanel(panel) {
  const otherPanel = panel === 'original' ? 'translated' : 'original';
  if (!pdfDocs[otherPanel] && !pageWrappers[otherPanel]?.length) return;

  const container = document.getElementById(`pdf-container-${panel}`);
  const otherContainer = document.getElementById(`pdf-container-${otherPanel}`);
  const metrics = pageMetrics[panel];
  const otherMetrics = pageMetrics[otherPanel];
  if (!container || !otherContainer || !metrics?.length || !otherMetrics?.length) return;
  if (otherContainer.classList.contains('hidden') || otherContainer.clientHeight <= 0) return;

  const { pageIdx, fraction } = pageScrollPosition(panel, container.scrollTop);
  const mirroredTop = targetScrollTop(otherPanel, pageIdx, fraction);
  mirroredScrollTops[otherPanel] = mirroredTop;
  otherContainer.scrollTop = mirroredTop;
  updatePageInfo(otherPanel, otherContainer.scrollTop);
  scheduleOtherPanelRender(otherPanel, otherContainer);
}

function updatePageInfo(panel, scrollTop) {
  const metrics = pageMetrics[panel];
  if (!metrics || metrics.length === 0) return;

  // Reuse the same anchor logic as scroll sync so the page indicator and the
  // mirrored panel always agree on the "current" page.
  const { pageIdx } = pageScrollPosition(panel, scrollTop);
  const infoEl = document.getElementById(`page-info-${panel}`);
  if (infoEl) infoEl.textContent = `第 ${pageIdx + 1} / ${metrics.length} 页`;
}

function toggleSyncScroll() {
  syncScrollEnabled = !syncScrollEnabled;
  if (!syncScrollEnabled) resetScrollSyncScheduling();
  const btn = document.getElementById('btn-sync-scroll');
  if (btn) {
    btn.textContent = syncScrollEnabled ? '同步滚动: 开' : '同步滚动: 关';
    btn.classList.toggle('btn-primary', syncScrollEnabled);
    btn.classList.toggle('btn-outline', !syncScrollEnabled);
  }
}

let viewportResizeTimer = null;
window.addEventListener('resize', () => {
  if (effectiveReaderMode() !== 'image') return;
  clearTimeout(viewportResizeTimer);
  viewportResizeTimer = setTimeout(() => {
    const positions = {};
    for (const panel of ['original', 'translated']) {
      const container = document.getElementById(`pdf-container-${panel}`);
      if (!container || !pageMetrics[panel]?.length) continue;
      positions[panel] = pageScrollPosition(panel, container.scrollTop);
      refreshImagePageMetrics(panel);
    }
    for (const panel of ['original', 'translated']) {
      const position = positions[panel];
      const container = document.getElementById(`pdf-container-${panel}`);
      if (!position || !container) continue;
      container.scrollTop = targetScrollTop(panel, position.pageIdx, position.fraction);
    }
    if (syncScrollEnabled) syncScrollFromPanel('original');
  }, 120);
});

async function cancelTranslation() {
  if (!currentPaper) return;
  try {
    await api.cancelTranslation(currentPaper.id);
    toastInfo('翻译取消请求已发送');
  } catch (e) {
    toastError(e.message);
  }
}

// === Translation ===
let translating = false;

function getTranslationBackend() {
  return document.getElementById('translation-backend')?.value || '';
}

async function startTranslate() {
  if (!currentPaper) return;
  const quality = document.getElementById('quality-preset')?.value || 'balanced';
  const options = {
    preserve_graphics_text: getPreserveGraphicsTextOption(),
    skip_overflow: document.getElementById('skip-overflow')?.checked || false,
    qa_mode: document.getElementById('qa-mode')?.value || 'single',
    qa_max_passes: 4,
    ocr_mode: document.getElementById('ocr-mode')?.value || 'off',
  };
  doTranslateDirect(currentPaper.id, getTranslationBackend(), quality, options);
}

async function quickTranslate(paperId) {
  doTranslateDirect(paperId, '', 'balanced');
}

function showTranslationSubmitting(paperId) {
  if (translationPollId) {
    clearInterval(translationPollId);
    translationPollId = null;
  }
  translationPollPaperId = paperId;
  translationPollGeneration++;
  const prog = document.getElementById('translation-progress');
  const fill = document.getElementById('trans-progress-fill');
  const statusEl = document.getElementById('trans-status');
  const percentEl = document.getElementById('trans-percent');
  const logEl = document.getElementById('trans-log');
  const titleEl = document.getElementById('trans-title');

  if (prog) prog.classList.remove('hidden');
  if (fill) {
    setProgressValue(fill, 2);
    fill.style.background = '';
    fill.classList.add('progress-fill-active', 'progress-fill-pending');
  }
  if (percentEl) percentEl.textContent = '0%';
  if (statusEl) statusEl.textContent = '正在提交翻译任务... 0s';
  if (titleEl) {
    const paper = currentPaper && currentPaper.id === paperId
      ? currentPaper
      : papers.find(p => p.id === paperId);
    titleEl.textContent = paper?.title || '';
  }
  if (logEl) logEl.innerHTML = '';
  addTransLog('正在提交翻译任务，服务器确认后立即开始排队...');
}

function showTranslationStartFailure(message) {
  const fill = document.getElementById('trans-progress-fill');
  const statusEl = document.getElementById('trans-status');
  if (fill) {
    fill.classList.remove('progress-fill-active', 'progress-fill-pending');
    fill.style.background = 'var(--error)';
  }
  if (statusEl) statusEl.textContent = '启动失败';
  addTransLog(message || '翻译任务启动失败', 'error');
}

async function doTranslateDirect(paperId, backend, quality, options = {}) {
  if (translating) return;
  translating = true;
  showTranslationSubmitting(paperId);
  try {
    const normalizedOptions = { preserve_graphics_text: true, ...options };
    await api.translatePaper(paperId, backend, quality, normalizedOptions);
    pollTranslationStatus(paperId);
  } catch (e) {
    showTranslationStartFailure(e.message);
    toastError(e.message);
  } finally {
    translating = false;
  }
}

function pollTranslationStatus(paperId) {
  // Clear any existing poll
  if (translationPollId) {
    clearInterval(translationPollId);
    translationPollId = null;
  }
  translationPollPaperId = paperId;
  const pollGeneration = ++translationPollGeneration;

  const prog = document.getElementById('translation-progress');
  const fill = document.getElementById('trans-progress-fill');
  const statusEl = document.getElementById('trans-status');
  const percentEl = document.getElementById('trans-percent');
  const logEl = document.getElementById('trans-log');
  const titleEl = document.getElementById('trans-title');
  prog.classList.remove('hidden');

  // Start elapsed time timer
  const startTime = Date.now();
  if (fill) {
    setProgressValue(fill, 3);
    fill.style.background = '';
    fill.classList.add('progress-fill-active', 'progress-fill-pending');
  }
  if (percentEl) percentEl.textContent = '0%';
  if (statusEl) statusEl.textContent = '准备翻译... 0s · 等待首批进度';

  // Show paper title in progress panel
  if (titleEl) {
    const paper = papers.find(p => p.id === paperId);
    titleEl.textContent = paper?.title || (
      currentPaper?.id === paperId ? currentPaper.title : ''
    );
  }
  if (logEl) logEl.innerHTML = '';
  addTransLog('已提交翻译任务，正在等待首批进度...');

  const POLL_INTERVAL_MS = 2000;
  const MAX_POLLS = Math.ceil((35 * 60 * 1000) / POLL_INTERVAL_MS);
  const MAX_CONSECUTIVE_ERRORS = 10; // stop after 20s of consecutive failures
  let pollCount = 0;
  let consecutiveErrors = 0;
  let statusRequestInFlight = false;
  let lastPct = 0;
  let lastPctTime = startTime;
  let smoothedRate = 0;

  async function refreshTranslationStatus() {
    if (
      translationPollPaperId !== paperId
      || pollGeneration !== translationPollGeneration
    ) return;
    if (statusRequestInFlight) return;
    statusRequestInFlight = true;
    pollCount++;
    if (pollCount > MAX_POLLS) {
      clearInterval(translationPollId);
      translationPollId = null;
      translationPollPaperId = null;
      statusEl.textContent = '翻译超时';
      addTransLog('翻译超时，请稍后重试', 'error');
      fill.classList.remove('progress-fill-active', 'progress-fill-pending');
      fill.style.background = 'var(--error)';
      loadPapers();
      statusRequestInFlight = false;
      return;
    }

    try {
      const paper = await api.getPaper(paperId);
      if (
        translationPollPaperId !== paperId
        || pollGeneration !== translationPollGeneration
      ) return;
      consecutiveErrors = 0;
      if (titleEl) titleEl.textContent = paper.title || titleEl.textContent;
      const progress = Math.max(0, Math.min(1, Number(paper.translation_progress) || 0));
      const pct = Math.round(progress * 100);
      const isTranslating = paper.translation_status === 'translating';
      const waitingForProgress = isTranslating && pct <= 0;
      const visiblePct = waitingForProgress ? 3 : pct;
      setProgressValue(fill, visiblePct);
      fill.classList.toggle('progress-fill-active', isTranslating);
      fill.classList.toggle('progress-fill-pending', waitingForProgress);
      if (percentEl) percentEl.textContent = `${pct}%`;

      // Display server-side translation log
      if (paper.translation_log && logEl) {
        const logLines = paper.translation_log.split('\n').filter(l => l.trim());
        logEl.innerHTML = logLines.map(l => {
          const cls = l.includes('失败') ? 'error' : l.includes('完成') ? 'success' : '';
          return `<div class="log-entry ${cls}">${esc(l)}</div>`;
        }).join('');
        logEl.scrollTop = logEl.scrollHeight;
      }

      const elapsed = Math.floor((Date.now() - startTime) / 1000);
      const elapsedStr = elapsed < 60 ? `${elapsed}s` : `${Math.floor(elapsed / 60)}m${elapsed % 60}s`;
      const now = Date.now();
      if (pct > lastPct) {
        const deltaPct = pct - lastPct;
        const deltaSeconds = Math.max(1, (now - lastPctTime) / 1000);
        const rate = deltaPct / deltaSeconds;
        smoothedRate = smoothedRate ? smoothedRate * 0.65 + rate * 0.35 : rate;
        lastPct = pct;
        lastPctTime = now;
      }
      const serverEtaStr = paper.translation_eta
        ? ` · 预计剩余 ${paper.translation_eta}`
        : '';
      const etaStr = serverEtaStr || (smoothedRate > 0 && pct > 0 && pct < 100
        ? ` · 预计剩余 ${formatEta(Math.ceil((100 - pct) / smoothedRate))}`
        : '');

      if (paper.translation_status === 'completed') {
        clearInterval(translationPollId);
        translationPollId = null;
        translationPollPaperId = null;
        fill.classList.remove('progress-fill-active', 'progress-fill-pending');
        setProgressValue(fill, 100);
        statusEl.textContent = `翻译完成 (${elapsedStr})`;
        setTimeout(() => {
          if (pollGeneration !== translationPollGeneration) return;
          prog.classList.add('hidden');
          if (currentPaper && currentPaper.id === paperId) {
            openReader(paperId);
          }
          loadPapers();
        }, 1500);
      } else if (paper.translation_status === 'failed') {
        clearInterval(translationPollId);
        translationPollId = null;
        translationPollPaperId = null;
        fill.classList.remove('progress-fill-active', 'progress-fill-pending');
        statusEl.textContent = `翻译失败 (${elapsedStr})`;
        fill.style.background = 'var(--error)';
        loadPapers();
      } else if (paper.translation_status === 'repairing') {
        clearInterval(translationPollId);
        translationPollId = null;
        translationPollPaperId = null;
        fill.classList.remove('progress-fill-active', 'progress-fill-pending');
        setProgressValue(fill, Math.max(1, pct));
        fill.style.background = 'var(--warning)';
        statusEl.textContent = '待修复（任务已停止，已保留最佳译文）';
        addTransLog('任务已停止且不占用翻译队列；修复发布后会自动重试');
        loadPapers();
      } else {
        const stage = paper.translation_stage || (waitingForProgress ? '准备翻译' : '翻译中');
        const pendingHint = waitingForProgress ? ' · 等待首批进度' : '';
        statusEl.textContent = `${stage}... ${elapsedStr}${pendingHint}${etaStr}`;
      }
    } catch (e) {
      consecutiveErrors++;
      if (consecutiveErrors >= MAX_CONSECUTIVE_ERRORS) {
        clearInterval(translationPollId);
        translationPollId = null;
        translationPollPaperId = null;
        statusEl.textContent = '连接中断';
        addTransLog('无法连接服务器，请检查网络后重试', 'error');
        fill.classList.remove('progress-fill-active', 'progress-fill-pending');
        fill.style.background = 'var(--error)';
        loadPapers();
      }
    } finally {
      statusRequestInFlight = false;
    }
  }

  refreshTranslationStatus();
  translationPollId = setInterval(refreshTranslationStatus, POLL_INTERVAL_MS);
}

function formatEta(seconds) {
  if (!isFinite(seconds) || seconds < 0) return '--';
  if (seconds < 60) return `${seconds}s`;
  const minutes = Math.floor(seconds / 60);
  const rest = seconds % 60;
  if (minutes < 60) return `${minutes}m${String(rest).padStart(2, '0')}s`;
  const hours = Math.floor(minutes / 60);
  return `${hours}h${String(minutes % 60).padStart(2, '0')}m`;
}

function addTransLog(msg, cls = '') {
  const logEl = document.getElementById('trans-log');
  if (!logEl) return;
  const entry = document.createElement('div');
  entry.className = `log-entry ${cls}`;
  const time = new Date().toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  entry.textContent = `[${time}] ${msg}`;
  logEl.appendChild(entry);
  logEl.scrollTop = logEl.scrollHeight;
}

// === QA Report ===
async function showQaReport() {
  if (!currentPaper) return;
  hideEditableFiguresPanel();
  const panel = document.getElementById('qa-report-panel');
  const content = document.getElementById('qa-report-content');
  if (!panel || !content) return;
  panel.classList.remove('hidden');
  content.innerHTML = '<div class="qa-report-loading">加载中...</div>';

  try {
    const report = await api.getQaReport(currentPaper.id);
    renderQaReport(report);
  } catch (e) {
    content.innerHTML = `<div class="qa-report-error">${esc(e.message || '质检报告不可用')}</div>`;
  }
}

function hideQaReportPanel() {
  const panel = document.getElementById('qa-report-panel');
  if (panel) panel.classList.add('hidden');
}

function renderQaReport(report) {
  const content = document.getElementById('qa-report-content');
  if (!content) return;
  const issues = Array.isArray(report.issues) ? report.issues : [];
  const passHistory = Array.isArray(report.pass_history) ? report.pass_history : [];
  const status = report.status || 'unknown';
  const statusText = qaStatusLabel(status);
  const passHistoryHtml = passHistory.length > 0
    ? `
      <div class="qa-pass-history">
        ${passHistory.map(item => `
          <div class="qa-pass-item">
            <span>第 ${Number(item.pass || 0)} 轮</span>
            <span>错误 ${Number(item.error_count || 0)}</span>
            <span>警告 ${Number(item.warning_count || 0)}</span>
            ${item.repair_attempted_after ? '<span>已触发修复</span>' : ''}
            ${Array.isArray(item.issue_codes) && item.issue_codes.length
              ? `<span>${item.issue_codes.map(code => esc(code)).join(', ')}</span>`
              : ''}
          </div>
        `).join('')}
      </div>
    `
    : '';
  const issueHtml = issues.length > 0
    ? issues.map(issue => `
      <div class="qa-issue qa-${sanitizeClass(issue.severity || 'warning')}">
        <div class="qa-issue-title">
          <span>第 ${Number(issue.page || 0)} 页</span>
          <span>${esc(issue.code || 'unknown')}</span>
          <span>${esc(issue.severity || 'warning')}</span>
        </div>
        <div class="qa-issue-message">${esc(issue.message || '')}</div>
      </div>
    `).join('')
    : '<div class="qa-report-empty">未发现需要处理的问题</div>';

  content.innerHTML = `
    <div class="qa-summary">
      <div class="qa-status qa-status-${sanitizeClass(status)}">${esc(statusText)}</div>
      <div>轮次：${Number(report.passes_run || 0)}</div>
      <div>错误：${Number(report.error_count || 0)}</div>
      <div>警告：${Number(report.warning_count || 0)}</div>
      <div>自动修复：${report.repair_attempted ? '是' : '否'}</div>
    </div>
    ${passHistoryHtml}
    <div class="qa-issues">${issueHtml}</div>
  `;
}

function qaStatusLabel(status) {
  const map = {
    passed: '通过',
    warning: '有警告',
    failed: '未通过',
    qa_failed: '检查失败',
    unknown: '未知',
  };
  return map[status] || status;
}

// === Editable Figure Sources ===
async function showEditableFigures() {
  if (!currentPaper) return;
  hideQaReportPanel();
  const panel = document.getElementById('editable-figures-panel');
  const content = document.getElementById('editable-figures-content');
  if (!panel || !content) return;
  panel.classList.remove('hidden');
  content.innerHTML = '<div class="side-panel-loading">加载中...</div>';

  try {
    const manifest = await api.getEditableFigureManifest(currentPaper.id);
    renderEditableFigureManifest(manifest);
  } catch (e) {
    content.innerHTML = `
      <div class="side-panel-empty">
        <div>${esc(e.message || '还没有图形素材清单')}</div>
        <button class="btn btn-sm btn-primary" data-action="extract-editable-figures">提取图形素材</button>
      </div>
    `;
  }
}

async function extractEditableFigures() {
  if (!currentPaper) return;
  hideQaReportPanel();
  const panel = document.getElementById('editable-figures-panel');
  const content = document.getElementById('editable-figures-content');
  if (!panel || !content) return;
  panel.classList.remove('hidden');
  content.innerHTML = '<div class="side-panel-loading">正在从原始 PDF 提取图形区域...</div>';

  try {
    const manifest = await api.extractEditableFigures(currentPaper.id);
    renderEditableFigureManifest(manifest);
    toastSuccess(`已提取 ${Number(manifest.figure_count || 0)} 个图形素材`);
  } catch (e) {
    content.innerHTML = `<div class="side-panel-error">${esc(e.message || '图形素材提取失败')}</div>`;
  }
}

function hideEditableFiguresPanel() {
  const panel = document.getElementById('editable-figures-panel');
  if (panel) panel.classList.add('hidden');
}

function renderEditableFigureManifest(manifest) {
  const content = document.getElementById('editable-figures-content');
  if (!content) return;
  const figures = Array.isArray(manifest.figures) ? manifest.figures : [];
  const audit = manifest.audit || {};
  const figureHtml = figures.length > 0
    ? figures.slice(0, 20).map(figure => `
      <div class="figure-source-item">
        <div class="figure-source-title">
          <span>${esc(figure.figure_id || 'figure')}</span>
          <span>第 ${Number(figure.page || 0)} 页</span>
          <span>${esc(figure.status || 'unknown')}</span>
        </div>
        <div class="figure-source-meta">
          ${Number(figure.width || 0)} × ${Number(figure.height || 0)} px
          · ${esc(figure.image_path || '')}
        </div>
      </div>
    `).join('')
    : '<div class="side-panel-empty">没有检测到可提取的图形区域</div>';

  content.innerHTML = `
    <div class="asset-summary">
      <div><strong>${Number(manifest.figure_count || figures.length)}</strong><span>图形</span></div>
      <div><strong>${esc(manifest.status || 'unknown')}</strong><span>状态</span></div>
      <div><strong>${audit.ok ? '通过' : '需处理'}</strong><span>审计</span></div>
      <div><strong>${Number(audit.failed || 0)}</strong><span>问题</span></div>
    </div>
    <div class="figure-source-actions">
      <button class="btn btn-sm btn-primary" data-action="extract-editable-figures">重新提取</button>
    </div>
    <div class="figure-source-list">${figureHtml}</div>
    ${renderEditableFigureCommands(manifest)}
  `;
}

function renderEditableFigureCommands(manifest) {
  const commands = Array.isArray(manifest.next_commands) ? manifest.next_commands : [];
  if (!commands.length) return '';
  return `
    <div class="command-block">
      <div class="command-block-title">下一步</div>
      ${commands.map(command => `<code>${esc(command)}</code>`).join('')}
    </div>
  `;
}

// === Downloads ===
async function downloadFile(url) {
  try {
    const res = await apiFetch(url);
    if (!res.ok) throw new Error(await errorDetail(res, '下载失败'));
    const blob = await res.blob();
    const objectUrl = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = objectUrl;
    a.download = '';
    a.style.display = 'none';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(objectUrl), 1000);
  } catch (e) {
    toastError(e.message || '下载失败');
  }
}

function downloadTranslated() {
  if (currentPaper) downloadFile(`/api/papers/${currentPaper.id}/download/translated`);
}
function downloadDual() {
  if (currentPaper) downloadFile(`/api/papers/${currentPaper.id}/download/dual`);
}
function downloadTranslatedById(id) {
  downloadFile(`/api/papers/${id}/download/translated`);
}
function downloadDualById(id) {
  downloadFile(`/api/papers/${id}/download/dual`);
}

// === Delete ===
async function confirmDelete(id, title) {
  if (!confirm(`确定删除 "${title}"？`)) return;
  try {
    await api.deletePaper(id);
    toastSuccess('论文已删除');
    loadPapers();
    if (currentPaper && currentPaper.id === id) showLibrary();
  } catch (e) {
    toastError('删除失败');
  }
}

// === Resizer ===
let resizeTimer = null;

function initResizer() {
  const resizer = document.getElementById('resizer');
  const left = document.getElementById('left-panel');
  const right = document.getElementById('right-panel');
  if (!resizer) return;

  const isStacked = () => window.matchMedia('(max-width: 768px)').matches;
  let startPosition;
  let startFirstSize;

  function setResizerSemantics(percent = 50) {
    resizer.setAttribute('aria-orientation', isStacked() ? 'horizontal' : 'vertical');
    resizer.setAttribute('aria-valuenow', String(Math.round(percent)));
  }

  function setPanelSplit(percent) {
    const bounded = Math.max(20, Math.min(80, percent));
    const parentRect = left.parentElement.getBoundingClientRect();
    if (isStacked()) {
      const total = Math.max(400, left.getBoundingClientRect().height + right.getBoundingClientRect().height);
      left.style.flex = `0 0 ${total * bounded / 100}px`;
      right.style.flex = `0 0 ${total * (100 - bounded) / 100}px`;
    } else {
      const available = Math.max(400, parentRect.width - resizer.getBoundingClientRect().width);
      left.style.flex = `0 0 ${available * bounded / 100}px`;
      right.style.flex = '1';
    }
    setResizerSemantics(bounded);
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(() => {
      reRenderPanel('original');
      reRenderPanel('translated');
    }, 200);
  }

  resizer.addEventListener('mousedown', e => {
    e.preventDefault();
    startPosition = isStacked() ? e.clientY : e.clientX;
    startFirstSize = isStacked()
      ? left.getBoundingClientRect().height
      : left.getBoundingClientRect().width;
    document.body.style.userSelect = 'none';
    document.body.style.cursor = isStacked() ? 'row-resize' : 'col-resize';
    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', () => {
      document.removeEventListener('mousemove', onMove);
      document.body.style.userSelect = '';
      document.body.style.cursor = '';
      reRenderPanel('original');
      reRenderPanel('translated');
    }, { once: true });
  });

  function onMove(e) {
    const currentPosition = isStacked() ? e.clientY : e.clientX;
    const parentRect = left.parentElement.getBoundingClientRect();
    const available = isStacked()
      ? left.getBoundingClientRect().height + right.getBoundingClientRect().height
      : parentRect.width - resizer.getBoundingClientRect().width;
    const firstSize = startFirstSize + currentPosition - startPosition;
    setPanelSplit(firstSize / Math.max(1, available) * 100);
  }

  resizer.addEventListener('keydown', e => {
    const decrementKey = isStacked() ? 'ArrowUp' : 'ArrowLeft';
    const incrementKey = isStacked() ? 'ArrowDown' : 'ArrowRight';
    if (![decrementKey, incrementKey, 'Home', 'End'].includes(e.key)) return;
    const current = Number(resizer.getAttribute('aria-valuenow')) || 50;
    const next = e.key === 'Home' ? 20 : e.key === 'End' ? 80 : current + (e.key === incrementKey ? 5 : -5);
    setPanelSplit(next);
    e.preventDefault();
  });

  // Double-click to reset to 50/50 split
  resizer.addEventListener('dblclick', () => {
    if (isStacked()) {
      left.style.flex = '0 0 50vh';
      right.style.flex = '0 0 50vh';
    } else {
      left.style.flex = '1';
      right.style.flex = '1';
    }
    setResizerSemantics(50);
    reRenderPanel('original');
    reRenderPanel('translated');
  });

  window.addEventListener('resize', () => {
    setResizerSemantics(Number(resizer.getAttribute('aria-valuenow')) || 50);
  });
  setResizerSemantics();
}

function reRenderPanel(panel) {
  const pdf = pdfDocs[panel];
  if (!pdf) return;
  const container = document.getElementById(`pdf-container-${panel}`);
  if (!container) return;

  // Clear rendered pages and re-calculate scale
  renderedPages[panel] = new Set();
  const metrics = pageMetrics[panel];
  if (!metrics || metrics.length === 0) return;

  // Use base dimensions (at RENDER_SCALE) to avoid compounding mutations
  const baseScale = metrics._baseScale || RENDER_SCALE;
  const containerWidth = availablePdfWidth(container);
  const maxPageWidth = Math.max(...metrics.map(m => m.baseWidth));
  const adaptiveScale = Math.max(MIN_SCALE, Math.min(MAX_SCALE, containerWidth / maxPageWidth * baseScale));
  pageMetrics[panel]._adaptiveScale = adaptiveScale;

  // Update wrapper sizes from base dimensions
  const wrappers = pageWrappers[panel];
  const scaleRatio = adaptiveScale / baseScale;
  for (let i = 0; i < metrics.length; i++) {
    const w = metrics[i].baseWidth * scaleRatio;
    const h = metrics[i].baseHeight * scaleRatio;
    metrics[i].width = w;
    metrics[i].height = h;
    metrics[i].top = i === 0 ? 0 : metrics[i - 1].top + metrics[i - 1].height + PAGE_GAP_PX;
    if (wrappers[i]) {
      wrappers[i].style.width = w + 'px';
      wrappers[i].style.height = h + 'px';
      wrappers[i].innerHTML = ''; // Clear canvas
    }
  }

  // Re-render visible pages
  void renderVisiblePages(panel, container);
}

// === Helpers ===
const _escDiv = document.createElement('div');
function esc(s) {
  _escDiv.textContent = s || '';
  return _escDiv.innerHTML.replace(/'/g, '&#39;');
}

function sanitizeClass(s) {
  return String(s || '').replace(/[^a-zA-Z0-9_-]/g, '');
}

function formatSize(bytes) {
  if (bytes == null || isNaN(bytes)) return '0 B';
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
  if (bytes < 1024 * 1024 * 1024) return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  return (bytes / (1024 * 1024 * 1024)).toFixed(1) + ' GB';
}

function parseServerTime(iso) {
  if (!iso) return null;
  // Stored timestamps are UTC; older servers emit them without an offset,
  // which browsers would otherwise read as local time.
  const hasOffset = /(?:Z|[+-]\d{2}:?\d{2})$/i.test(iso);
  const d = new Date(hasOffset ? iso : `${iso}Z`);
  return isNaN(d.getTime()) ? null : d;
}

function formatDate(iso) {
  const d = parseServerTime(iso);
  if (!d) return '';
  return `${d.getMonth() + 1}/${d.getDate()} ${d.getHours()}:${String(d.getMinutes()).padStart(2, '0')}`;
}

function statusLabel(s) {
  const map = { pending: '待翻译', translating: '翻译中', repairing: '待修复（任务已停止）', completed: '已完成', failed: '失败' };
  return map[s] || esc(s);
}

// === Toast Notifications ===
function showToast(message, type = 'info', duration = 3000) {
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    container.className = 'toast-container';
    container.setAttribute('aria-live', 'polite');
    container.setAttribute('aria-relevant', 'additions');
    document.body.appendChild(container);
  }

  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  toast.setAttribute('role', type === 'error' ? 'alert' : 'status');
  toast.setAttribute('aria-atomic', 'true');
  toast.textContent = message;
  container.appendChild(toast);

  // Auto remove after duration
  setTimeout(() => {
    toast.classList.add('toast-out');
    toast.addEventListener('animationend', () => toast.remove());
  }, duration);
}

function toastSuccess(msg) { showToast(msg, 'success'); }
function toastError(msg) { showToast(msg, 'error', 5000); }
function toastWarning(msg) { showToast(msg, 'warning', 4000); }
function toastInfo(msg) { showToast(msg, 'info'); }

// === Event Delegation ===
const actionHandlers = {
  'show-upload': showUpload,
  'show-library': showLibrary,
  'logout': logout,
  'show-provider-settings': showProviderSettings,
  'hide-provider-settings': hideProviderSettings,
  'save-provider-credential': saveProviderCredential,
  'refresh-provider-models': refreshProviderModelsForRow,
  'delete-provider-credential': deleteProviderCredential,
  'toggle-reader-mode': toggleReaderMode,
  'batch-translate': batchTranslate,
  'do-upload': doUpload,
  'cancel-upload': cancelUpload,
  'start-translate': startTranslate,
  'retranslate': startTranslate,
  'cancel-translate': cancelTranslation,
  'toggle-sync-scroll': toggleSyncScroll,
  'copy-pdf-selection': copyPdfSelection,
  'show-qa-report': showQaReport,
  'hide-qa-report': hideQaReportPanel,
  'show-editable-figures': showEditableFigures,
  'extract-editable-figures': extractEditableFigures,
  'hide-editable-figures': hideEditableFiguresPanel,
  'download-translated': downloadTranslated,
  'download-dual': downloadDual,
  'debounce-search': debounceSearch,
  'load-papers': loadPapers,
  'filter-by-tag': (e) => {
    const tag = e.target.dataset.tag;
    if (tag) {
      const tagInput = document.getElementById('tag-filter');
      if (tagInput) {
        tagInput.value = tag;
        loadPapers();
      }
    }
  },
  'handle-file-select': (e) => handleFileSelect(e.target),
  'open-reader': (e) => {
    const id = e.target.closest('[data-paper-id]')?.dataset.paperId;
    if (id) openReader(id);
  },
  'stop-propagation': (e) => e.stopPropagation(),
  'quick-translate': (e) => {
    const id = e.target.closest('[data-paper-id]')?.dataset.paperId;
    if (id) quickTranslate(id);
  },
  'download-translated-by-id': (e) => {
    const id = e.target.closest('[data-paper-id]')?.dataset.paperId;
    if (id) downloadTranslatedById(id);
  },
  'download-dual-by-id': (e) => {
    const id = e.target.closest('[data-paper-id]')?.dataset.paperId;
    if (id) downloadDualById(id);
  },
  'confirm-delete': (e) => {
    const el = e.target.closest('[data-paper-id]');
    if (el) confirmDelete(el.dataset.paperId, el.dataset.paperTitle || '');
  },
  'go-to-page': (e) => {
    const page = parseInt(e.target.dataset.page, 10);
    if (page > 0) goToPage(page);
  },
  'remove-file': (e) => {
    const index = parseInt(e.target.dataset.index, 10);
    if (!isNaN(index)) removeFile(index);
  },
};

document.addEventListener('click', (e) => {
  const el = e.target.closest('[data-action]');
  const action = el?.dataset.action;
  if (action && actionHandlers[action]) {
    actionHandlers[action](e);
  }
});

document.addEventListener('input', (e) => {
  const action = e.target.dataset.action;
  if (action && actionHandlers[action]) {
    actionHandlers[action](e);
  }
});

document.addEventListener('change', (e) => {
  const action = e.target.dataset.action;
  if (action && actionHandlers[action]) {
    actionHandlers[action](e);
  }
});

// === Keyboard Shortcuts ===
document.addEventListener('keydown', (e) => {
  const providerModal = document.getElementById('provider-settings-modal');
  if (trapModalFocus(providerModal, e)) return;

  // Escape: go back to library from upload/reader views
  if (e.key === 'Escape') {
    if (providerModal && !providerModal.classList.contains('hidden')) {
      hideProviderSettings();
      e.preventDefault();
      return;
    }
    const uploadView = document.getElementById('upload-view');
    const readerView = document.getElementById('reader-view');
    if (uploadView?.classList.contains('active') || readerView?.classList.contains('active')) {
      showLibrary();
      e.preventDefault();
    }
  }

  // Ctrl/Cmd + U: open upload view
  if ((e.ctrlKey || e.metaKey) && e.key === 'u') {
    const readerView = document.getElementById('reader-view');
    if (!readerView?.classList.contains('active')) {
      showUpload();
      e.preventDefault();
    }
  }

  // Ctrl/Cmd + Enter: start translation (in reader view)
  if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
    const readerView = document.getElementById('reader-view');
    if (readerView?.classList.contains('active') && currentPaper) {
      startTranslate();
      e.preventDefault();
    }
  }

  // Ctrl/Cmd + Shift + S: toggle sync scroll (in reader view)
  if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key === 'S') {
    const readerView = document.getElementById('reader-view');
    if (readerView?.classList.contains('active')) {
      toggleSyncScroll();
      e.preventDefault();
    }
  }
});

// === Init ===
document.addEventListener('DOMContentLoaded', () => {
  initDropZone();
  initResizer();
  updateCurrentUserBadge();
  updateReaderModeButton();
  loadPapers();
});
